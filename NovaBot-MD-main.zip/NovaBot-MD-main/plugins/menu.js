const fs = require("fs")
const { smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom} = require('../libs/fuctions.js'); 
const path = require("path") 
const chalk = require("chalk");
const moment = require('moment-timezone') 
const gradient = require('gradient-string') 
const fetch = require('node-fetch') 
const axios = require('axios')
const cheerio = require('cheerio')
const Jimp = require('jimp')
const os = require('os')

const menu = (m, command, conn, prefix, pushname, sender, pickRandom, fkontak) => {
if (global.db.data.users[m.sender].registered < true) return m.reply(info.registra)
if (command == 'menu' || command == 'menucompleto') {
let user = global.db.data.users[m.sender]
let totalreg = Object.keys(global.db.data.users).length
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
const date = moment.tz('America/Asunción').format('DD/MM/YYYY')
const time = moment.tz('America/Paraguay/Asunción').format('LT')
let wa = m.key.id.length > 21 ? 'Android' : m.key.id.substring(0, 2) == '3A' ? 'IOS' : 'whatsapp web'
m.react('🙌') 
let menu = `╔══════ ≪ •❈• ≫ ══════╗
║◤━━━━━ ☆. ∆ .☆ ━━━━━◥
║🎅 ${lenguaje['smsWel']()} @${sender.split("@")[0]} ${user.registered === true ? 'ͧͧͧͦꙶͣͤ✓' : ''} 👋🏻
║◤━━━━━ ☆. ∆ .☆ ━━━━━◥
║${lenguaje.menu.text} [ ${prefix} ]
║${lenguaje.menu.text2} ${date}
║${lenguaje.menu.text3} ${time}
║${lenguaje.menu.text4} ${vs}
║${lenguaje.menu.text5} ${Object.keys(global.db.data.users).length}
║${lenguaje.menu.text6} ${runtime(process.uptime())}
║${lenguaje.menu.text7} ${conn.public ? 'publico' : 'privado'}
║🎅 ${conn.user.id == global.numBot2 ? 'ʙᴏᴛ ᴏғᴄ : ᴇsᴛᴇ ᴇs ᴇʟ ʙᴏᴛ ᴏғᴄ' : `sᴏʏ ᴜɴ sᴜʙʙᴏᴛ ᴅᴇ : @${global.numBot.split`@`[0]}`}
║ 
║${lenguaje.menu.text8} ${user.limit}
║${lenguaje.menu.text9} ${user.level}
║${lenguaje.menu.text10} ${user.role}
║🎅 ᴇxᴘ : ${user.exp}
║🎅 ᴄᴏɪɴs : ${user.money}
║ 
║${lenguaje.menu.text11} ${rtotalreg} de ${totalreg}
║◤━━━━━ ☆. ∆ .☆ ━━━━━◥
╚══════ ≪ •❈• ≫ ══════╝

===============================
${lenguaje.menu.text12}
===============================

 ⃐ *ℹ️ ＩＮＦＯＢＯT*
├❥ᰰຼ ❏ ${prefix}reg 
├❥ᰰຼ _(Registrarte para poder usar el bot)_
├❥ᰰຼ ❏ ${prefix}unreg
├❥ᰰຼ _(Para borrar su registro)_
├❥ᰰຼ ❏ ${prefix}myns
├❥ᰰຼ _(Para ver tu numero de serie)_
├❥ᰰຼ ❏ ${prefix}estado 
├❥ᰰຼ _(Comprueba el estado del bot)_
├❥ᰰຼ ❏ ${prefix}ping 
├❥ _(Velocidad del bot)_
├❥ᰰຼ ❏ ${prefix}owner
├❥ᰰຼ ❏ ${prefix}creador
├❥ᰰຼ _(Te envia los contactos de mi creador)_

*🔄ＤＥＳＣＡＲＧＡ*
├❥ᰰຼ ❏ ${prefix}play 
├❥ᰰຼ _(Titulo/nombre de la canción para descargar el audio)_
├❥ᰰຼ ❏ ${prefix}play2
├❥ᰰຼ _(Titulo/nombre de la canción para descargar el video)_
├❥ᰰຼ ❏ ${prefix}play.1
├❥ᰰຼ ❏ ${prefix}play.2
├❥ᰰຼ ❏ ${prefix}musica
├❥ᰰຼ ❏ ${prefix}video
├❥ᰰຼ ❏ ${prefix}playdoc
├❥ᰰຼ ❏ ${prefix}play3
├❥ᰰຼ _(Descarga audio en documento)_
├❥ᰰຼ ❏ ${prefix}play4 
├❥ᰰຼ _(Descarga video en documento)_
├❥ᰰຼ ❏ ${prefix}yts 
├❥ᰰຼ  _(Busca los links para descarga el video)_
├❥ᰰຼ ❏ ${prefix}ytmp3
├❥ᰰຼ _(Ingresa el link para descargar el audio)_
├❥ᰰຼ ❏ ${prefix}ytmp4
├❥ᰰຼ _(Ingresa el link para descargar el video)_
├❥ᰰຼ ❏ ${prefix}spotify
├❥ᰰຼ ❏ ${prefix}music
├❥ᰰຼ _(Descarga musica de Spotify)_
├❥ᰰຼ ❏ ${prefix}gitclone
├❥ᰰຼ _(Ingresa el link del GitHub para descargar el repositorio)_
├❥ᰰຼ ❏ ${prefix}tiktok
├❥ᰰຼ _(Ingresa el link de tiktok para descargar el video)_
├❥ᰰຼ ❏ ${prefix}tiktokimg
├❥ᰰຼ ❏ ${prefix}ttimg
├❥ᰰຼ ❏ ${prefix}igstalk
├❥ᰰຼ _(Ingresa el nombre de un usuario de Instagram para ver su perfil)_
├❥ᰰຼ ❏ ${prefix}facebook
├❥ᰰຼ ❏ ${prefix}fb
├❥ᰰຼ _(Descarga videos de Facebook)_
├❥ᰰຼ ❏ ${prefix}instagram
├❥ᰰຼ ❏ ${prefix}ig
├❥ᰰຼ _(Descarga videos de Instagram)_
├❥ᰰຼ ❏ ${prefix}mediafire
├❥ᰰຼ (descarga archivos de mediafire)_
├❥ᰰຼ ❏ ${prefix}gdrive
├❥ᰰຼ _(Descarga archivos de gdrive)_

  *B U S C A D O R E S*
├❥ᰰຼ ❏ ${prefix}google 
├❥ᰰຼ _(Ingresa nombre de lo que quiere buscar)_
├❥ᰰຼ ❏ ${prefix}ia 
├❥ᰰຼ _(Ingresa el texto de lo que quiere buscar con la (IA)_
├❥ᰰຼ ❏ ${prefix}imagen
├❥ᰰຼ _Ingresa el texto de la imagen que quiere buscar_
├❥ᰰຼ ❏ ${prefix}traducir
├❥ᰰຼ _(Traducir algun texto)_
├❥ᰰຼ ❏ ${prefix}wallpaper
├❥ᰰຼ _(Buscar imagen del wallpaper)_
├❥ᰰຼ ❏ ${prefix}ss 
├❥ᰰຼ _(Ingresa un link para mandar captura)_
├❥ᰰຼ ❏ ${prefix}dall-e
├❥ᰰຼ ❏ ${prefix}ia2
├❥ᰰຼ _(Crea imagenes con la (IA)_
࣭۫*

*S T I C K E R S *
├❥ᰰຼ ❏ ${prefix}s
├❥ᰰຼ ❏ ${prefix}sticker 
├❥ຼ ❏ 
࣭۫*`
conn.sendMessage(m.chat, { text: menu,  
contextInfo:{  
forwardingScore: 9999999,  
isForwarded: true,   
mentionedJid:[sender, numBot],  
"externalAdReply": {  
"showAdAttribution": true,  
"renderLargerThumbnail": true,  
"title": wm,   
"containsAutoReply": true,  
"mediaType": 1,   
"thumbnail": imagen2, 
sourceUrl: `${pickRandom([nna, nn, md, yt])}`
}}}, { quoted: fkontak, ephemeralExpiration: 24*60*100, disappearingMessagesInChat: 24*60*100}) 
}


if (command == 'nuevo' || command == 'extreno') {
conn.sendMessage(m.chat, { text: `${lenguaje.menu.text15} [ ${vs} ]\n\n${lenguaje.menu.text16}`, contextInfo:{mentions: [sender], forwardingScore: 9999999, isForwarded: true, "externalAdReply": {"showAdAttribution": true, "containsAutoReply": true, "title": ` ${wm}`, "body": ` ${vs}`, "previewType": "PHOTO", thumbnail: imagen1, sourceUrl: `${pickRandom([nna, nn, md, yt])}`}}}, { quoted: fkontak, ephemeralExpiration: 24*60*100, disappearingMessagesInChat: 24*60*100})}

if (command == 'reglas') {
conn.sendMessage(m.chat, { text: `${lenguaje.menu.text17}`, contextInfo:{mentions: [sender], forwardingScore: 9999999, isForwarded: true, "externalAdReply": {"showAdAttribution": true, "containsAutoReply": true, "title": ` ${wm}`, "body": ` ${vs}`, "previewType": "PHOTO", thumbnail: imagen1, sourceUrl: `${pickRandom([nna, nn, md, yt])}`}}}, { quoted: fkontak, ephemeralExpiration: 24*60*100, disappearingMessagesInChat: 24*60*100})}}

module.exports = { menu }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
